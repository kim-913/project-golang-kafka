# This is a sample Python script.

# Press ⌃R to execute it or replace it with your code.
# Press Double ⇧ to search everywhere for classes, files, tool windows, actions, and settings.

import mysql.connector
import random
import string

mydb = mysql.connector.connect(
    host='localhost',
    user='root',
    password='Kzr54321',
    port='3306',
    database='test_project'
)

mycursor = mydb.cursor()

# generate values
sql = 'INSERT INTO test (id, name, address, Continent) VALUES (%s, %s, %s, %s)'

min_data = 1
max_data = 100000000

user_values = []
# generate id
IDs = list(range(min_data, max_data + 1))
random.shuffle(IDs)

# generate name
Names = []
for i in range(0, max_data):
    name = ''
    name += "".join(random.choice(string.ascii_lowercase) for i in range(random.randint(10, 15)))
    Names.append(name)


# generate address
Address = []
for i in range(0, max_data):
    address = ''
    rand_num = random.randint(1, 10000)
    address += str(rand_num) + ' '
    rand_string1 = ''
    rand_string1 += "".join(random.choice(string.ascii_lowercase) for i in range(2, 7))
    address += rand_string1 + ' '
    rand_string2 = ''
    rand_string2 += "".join(random.choice(string.ascii_lowercase) for i in range(15 - len(address), 20 - len(address)))
    address += rand_string2
    Address.append(address)

# generate continent
Continents = []
continent = ["North America", "Asia", "South America", "Europe", "Africa", "Australia"]
for i in range(0, max_data):
    user_continent = random.choice(continent)
    Continents.append(user_continent)

for i in range(0, max_data):
    values = []
    values.append(IDs[i])
    values.append(Names[i])
    values.append(Address[i])
    values.append(Continents[i])
    mycursor.executemany(sql, (values[0], values[1], values[2], values[3]))

mydb.commit()